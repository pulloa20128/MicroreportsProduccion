<?php

namespace App\Http\Controllers;

use App\Models\Evaluacion;
use App\Models\Machotes;
use App\Models\User;
use Illuminate\Http\Request;
use PDF;

class EvaluacionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $dato=evaluacion::all();
        return view('evaluacionindex', compact('dato'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
      $idUsuario=$_POST['idUsuario'];
      $MachoteVariable=$_POST['idMachote'];
      $usuario=User::findOrFail($idUsuario);
      $machote=Machotes::findOrFail($MachoteVariable);
      return view('evaluacioncreate', compact('usuario','machote'));
    }
    public function desplegable()
    {
        $user=User::all();
        $idMachote=Machotes::all();
        return view('evaluaciondesplegable', compact('user', 'idMachote'));
    }

    public function pdfdesplegable()
    {
        $idRespuesta=Evaluacion::all();
        return view('desplegablepdf', compact('idRespuesta'));
    }

    public function pdfver()
    {
        $idRespuesta=$_POST['idRespuesta'];
        $evaluacion=Evaluacion::find($idRespuesta);
        $pdf = PDF::loadView('pdf.reporteeva', compact('evaluacion'));
        return $pdf->stream();
        // return $pdf->download('Reporte Evaluacion_'.time().'.pdf');
        //return view('pdf.reporteeva',compact('evaluacion'));

    }

    public function pdfdesplegabledescarga()
    {
        $idRespuesta=Evaluacion::all();
        return view('desplegablepdfdescarga', compact('idRespuesta'));
    }
    public function descargarPDF()
    {
        $idRespuesta=$_POST['idRespuesta'];
        $evaluacion=Evaluacion::find($idRespuesta);
        $pdf = PDF::loadView('pdf.reporteeva', compact('evaluacion'));
         return $pdf->download('Reporte Evaluacion_'.time().'.pdf');
        //return view('pdf.reporteeva',compact('evaluacion'));
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
         $evaluacion=new Evaluacion();
         $evaluacion->idRespuesta= $request->post('idRespuesta');
         $evaluacion->nombreEvaluacion=$request->post('nombreEvaluacion');   
         $evaluacion->idUsuario=$request->post('idUsuario');   

         $evaluacion->pregunta1=$request->post('pregunta1');
         $evaluacion->respuesta1=$request->post('respuesta1');

        $evaluacion->pregunta2=$request->post('pregunta2');
        $evaluacion->respuesta2=$request->post('respuesta2');

        $evaluacion->pregunta3=$request->post('pregunta3');
        $evaluacion->respuesta3=$request->post('respuesta3');

        $evaluacion->pregunta4=$request->post('pregunta4');
        $evaluacion->respuesta4=$request->post('respuesta4');

        $evaluacion->pregunta5=$request->post('pregunta5');
        $evaluacion->respuesta5=$request->post('respuesta5');

        $evaluacion->pregunta6=$request->post('pregunta6');
        $evaluacion->respuesta6=$request->post('respuesta6');

        $evaluacion->pregunta7=$request->post('pregunta7');
        $evaluacion->respuesta7=$request->post('respuesta7');

        $evaluacion->pregunta8=$request->post('pregunta8');
        $evaluacion->respuesta8=$request->post('respuesta8');

        $evaluacion->pregunta9=$request->post('pregunta9');
        $evaluacion->respuesta9=$request->post('respuesta9');

        $evaluacion->pregunta10=$request->post('pregunta10');
        $evaluacion->respuesta10=$request->post('respuesta10');
        $evaluacion->save();
        return redirect()->route('evaluacion.index')->with("success","Agregado exitosamente");
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Evaluacion  $evaluacion
     * @return \Illuminate\Http\Response
     */
    

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Evaluacion  $evaluacion
     * @return \Illuminate\Http\Response
     */
    public function edit(Evaluacion $evaluacion)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Evaluacion  $evaluacion
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Evaluacion $evaluacion)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Evaluacion  $evaluacion
     * @return \Illuminate\Http\Response
     */

    public function deletedesplegable(){
        $idRespuesta=Evaluacion::all();
        return view('desplegabledelete',compact('idRespuesta'));
    }

    public function showevaluacion(){
        //parametro que llegan de desplegabledelete
        $idRespuesta=$_POST['idRespuesta'];
        $evaluacion=Evaluacion::find($idRespuesta);
       return view('evaluaciondelete', compact('evaluacion'));
         
         
    }

    public function destroyeva()
    {
        $idRespuesta=$_POST['idRespuesta'];
        $evaluacion=Evaluacion::find($idRespuesta);
        $evaluacion->delete();
        return redirect()->route("evaluacion.index")->with("success","Eliminado exitosamente");

    }
    

    
    
}