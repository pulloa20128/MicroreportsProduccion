<?php

namespace App\Http\Controllers;

use App\Models\Machotes;
use Illuminate\Http\Request;
use PDF;

class MachotesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //pagina inicio
        $dato=Machotes::all();    
        // $nombreMachote=
        // $dato2= \DB::select('SELECT NOMBREMACHOTE FROM MACHOTES WHERE IDMACHOTE="1212"'); 
        // \DB::insert('INSERT INTO MACHOTES (NOMBREMACHOTE) VALUES ($dato2)');

        return view('machotesindex', compact('dato')); 
        // return view('machotesindex', compact('dato','dato2')); 
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //vista donde agregamos datos
         return view('machotecreate');
    }

    public function create1()
    {
        //vista donde agregamos datos
         return view('machotesupdate1');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //sirve para guardar datos en la base de datos
        $machotes=new machotes();
        $machotes->idMachote= $request->post('idMachote');
        $machotes->nombreMachote=$request->post('nombreMachote');
        $machotes->pregunta1=$request->post('pregunta1');  
        $machotes->pregunta2=$request->post('pregunta2');
        $machotes->pregunta3=$request->post('pregunta3');
        $machotes->pregunta4=$request->post('pregunta4');
        $machotes->pregunta5=$request->post('pregunta5');
        $machotes->pregunta6=$request->post('pregunta6');
        $machotes->pregunta7=$request->post('pregunta7');
        $machotes->pregunta8=$request->post('pregunta8');
        $machotes->pregunta9=$request->post('pregunta9');
        $machotes->pregunta10=$request->post('pregunta10');
        $machotes->save();
        return redirect()->route('machotes.index')->with("success","Successfully added");
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\machotes  $machotes
     * @return \Illuminate\Http\Response
     */
    

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\machotes  $machotes
     * @return \Illuminate\Http\Response
     */
    public function edit($idMachote)
    {
        //sirve para traer los datos que se van a editar y los coloca en un formulario
       $machotes=Machotes::find($idMachote);
       return view('machotesedit', compact('machotes'));
     
    }
    public function prueba()
    {
    $idMachote=Machotes::all();   
    return view('prueba',compact('idMachote'));
     
    }
    

    public function actualizado()
    {
        $idMachote=$_POST['idMachote'];
        $machote=Machotes::findOrFail($idMachote);
        return view('actualizado',compact('machote'));
       
     
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\machotes  $machotes
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $idMachote)
    {
        //metodo actualiza los datos en la base de datos
        
        $machotes=machotes::find($idMachote);
        $machotes->idMachote = $request->post('idMachote');
        $machotes->nombreMachote = $request->post('nombreMachote');
        $machotes->pregunta1 = $request->post('pregunta1');
        $machotes->pregunta2 = $request->post('pregunta2');
        $machotes->pregunta3 = $request->post('pregunta3');
        $machotes->pregunta4 = $request->post('pregunta4');
        $machotes->pregunta5 = $request->post('pregunta5');
        $machotes->pregunta6 = $request->post('pregunta6');
        $machotes->pregunta7 = $request->post('pregunta7');
        $machotes->pregunta8 = $request->post('pregunta8');
        $machotes->pregunta9 = $request->post('pregunta9');
        $machotes->pregunta10 = $request->post('pregunta10');
        $machotes->save();
        return redirect()->route("machotes.index")->with("success","Actualizado exitosamente");       
    }

    public function imprimir($idMachote)
    {
        $machotes=Machotes::find($idMachote);
        $pdf = PDF::loadView('pdf.reportemachotes', compact('machotes'))->setPaper('a4','landscape');
        //return $pdf->stream();
         return $pdf->download('Reporte Machotes_'.time().'.pdf');
        //return view('pdf.reportemachotes',compact('machotes'));
    }

    public function ver($idMachote)
    {
        $machotes=Machotes::find($idMachote);
        $pdf = PDF::loadView('pdf.reportemachotes', compact('machotes'));
        return $pdf->stream();
         //return $pdf->download('Reporte Machotes_'.time().'.pdf');
        //return view('pdf.reportemachotes',compact('machotes'));
    }
    
    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\machotes  $machotes
     * @return \Illuminate\Http\Response
     */
    public function show($idMachote)
    {
        //servira para obbtener un registro de nuestra table
        $machotes=Machotes::find($idMachote);
        return view('machotedelete', compact('machotes'));
    }
    public function destroy($idMachote)
    {
        //elimina un registro
        $machotes=machotes::find($idMachote);
        $machotes->delete();
        return redirect()->route("machotes.index")->with("success","Eliminado exitosamente");
        
    }
}
