<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('evaluacion', function (Blueprint $table) {

            $table->BigIncrements('idRespuesta');  
            $table->string('nombreEvaluacion');
            $table->integer('idUsuario');  
            
            $table->string('pregunta1')->nullable();
            $table->boolean('respuesta1')->nullable();

            $table->string('pregunta2')->nullable();
            $table->boolean('respuesta2')->nullable();

            $table->string('pregunta3')->nullable();
            $table->boolean('respuesta3')->nullable();

            $table->string('pregunta4')->nullable();
            $table->boolean('respuesta4')->nullable();

            $table->string('pregunta5')->nullable();
            $table->boolean('respuesta5')->nullable();

            $table->string('pregunta6')->nullable();
            $table->boolean('respuesta6')->nullable();

            $table->string('pregunta7')->nullable();
            $table->boolean('respuesta7')->nullable();

            $table->string('pregunta8')->nullable();
            $table->boolean('respuesta8')->nullable();

            $table->string('pregunta9')->nullable();
            $table->boolean('respuesta9')->nullable();

            $table->string('pregunta10')->nullable();
            $table->boolean('respuesta10')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('evaluacion');
    }
};
